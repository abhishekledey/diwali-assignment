public class SQ_18 {
    public static void main(String[] args) {
        
    }
}
