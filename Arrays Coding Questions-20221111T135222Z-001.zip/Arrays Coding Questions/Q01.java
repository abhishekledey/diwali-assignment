public class Q01 {
  
    // Main driver method
    public static void main(String[] args)
    {
  
        int[] arr = { -7, -5, 5, 10, 0, 3, 20, 25, 12 };
  
        System.out.print("Elements of given array are: ");
  
        for (int i = 0; i < arr.length; i++) {
  
           
            System.out.print(arr[i] + " ");
        }
    }
}