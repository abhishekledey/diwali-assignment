
public class Q22StaticMethod 
{
    static int a = 42;
    int b = 99;
    public static void main (String args[])
    {
        System.out.println("static variable:" + a);
        System.out.println("non static variable:" + b);
    }
}