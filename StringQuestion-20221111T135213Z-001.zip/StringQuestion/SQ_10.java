public class SQ_10 {
    public static void main(String[] args) {
        int decimalExample = Integer.parseInt("67263");
        System.out.println(decimalExample);
    }
}
