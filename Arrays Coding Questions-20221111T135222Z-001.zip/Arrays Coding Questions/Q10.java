
public class Q10 {

}
