import java.util.Arrays;
import java.util.List;

public class Q21
{
    public static void main (String[] args)
    {
        String[] str = {"Rahul", "Utkarsh",
                          "Shubham", "Neelam", "Akash"};
 
     
        List<String> al = Arrays.asList(str);
 
        System.out.println(al);
    }
}