/*

      *
	 * *
	*   *
   * 	 *
  ************

*/

class pattern1
{
	public static void main(String args[])
	{
		for(int i=0;i<5;i++)
		{
			for(int j=4;j>i;j--)
			{
				System.out.print(" ");
			}
			for(int j=0;j<=1;j++)
			{
				System.out.print("* ");
			}
			for(int j=2;j<=)
			
          System.out.println();
		}
	}
}  