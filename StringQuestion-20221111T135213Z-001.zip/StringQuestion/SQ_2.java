import java.util.*;

public class SQ_2 {
    public static void main(String[] args) {
        String str = "Java";
        int b = str.compareTo("Java");
        if (b == 0)

            System.out.println("a");

        else
            System.out.println("not equal");
    }

}
