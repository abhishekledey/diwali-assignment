
public class Q24
{
    static int x = 17;
    public static void main(String...a)
    {
        System.out.println(x);                  //static variable can be called directly
        System.out.println(Q24.x);   //static variable can be called with class its name
    }
}